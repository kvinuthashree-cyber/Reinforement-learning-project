click on live server when the index.html file is open
got image.svg and submit.svg go to hugeicons and coy the url and create a file called submit.svg and image.svg and paste ur copied one in both of them respectively
link is generated frm gemini api keys